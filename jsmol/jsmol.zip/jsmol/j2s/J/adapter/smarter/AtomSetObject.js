Clazz.declarePackage ("J.adapter.smarter");
c$ = Clazz.decorateAsClass (function () {
this.atomSetIndex = 0;
Clazz.instantialize (this, arguments);
}, J.adapter.smarter, "AtomSetObject");
